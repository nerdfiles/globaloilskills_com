
PHP Version 5.4.32

System 	Linux box987.bluehost.com 3.12.26.1408748414 #1 SMP Fri Aug 22 18:03:32 CDT 2014 x86_64
Build Date 	Aug 27 2014 14:22:48
Server API 	CGI/FastCGI
Virtual Directory Support 	disabled
Configuration File (php.ini) Path 	/usr/php/54/etc
Loaded Configuration File 	/home2/thecoins/public_html/php.ini
Scan this dir for additional .ini files 	/usr/php/54/etc/php.d
Additional .ini files parsed 	(none)
PHP API 	20100412
PHP Extension 	20100525
Zend Extension 	220100525
Zend Extension Build 	API220100525,NTS
PHP Extension Build 	API20100525,NTS
Debug Build 	no
Thread Safety 	disabled
Zend Signal Handling 	disabled
Zend Memory Manager 	enabled
Zend Multibyte Support 	provided by mbstring
IPv6 Support 	enabled
DTrace Support 	disabled
Registered PHP Streams	https, ftps, compress.zlib, compress.bzip2, php, file, glob, data, http, ftp, phar, zip
Registered Stream Socket Transports	tcp, udp, unix, udg, ssl, sslv3, sslv2, tls
Registered Stream Filters	zlib.*, bzip2.*, convert.iconv.*, mcrypt.*, mdecrypt.*, string.rot13, string.toupper, string.tolower, string.strip_tags, convert.*, consumed, dechunk, http.*

This program makes use of the Zend Scripting Language Engine:
Zend Engine v2.4.0, Copyright (c) 1998-2014 Zend Technologies
    with Zend Guard Loader v3.3, Copyright (c) 1998-2013, by Zend Technologies

Configuration
bcmath
BCMath support 	enabled

Directive	Local Value	Master Value
bcmath.scale	0	0

bz2
BZip2 Support 	Enabled
Stream Wrapper support 	compress.bzip2://
Stream Filter support 	bzip2.decompress, bzip2.compress
BZip2 Version 	1.0.5, 10-Dec-2007

calendar
Calendar support 	enabled

cgi-fcgi
Directive	Local Value	Master Value
cgi.check_shebang_line	1	1
cgi.discard_path	0	0
cgi.fix_pathinfo	1	1
cgi.force_redirect	1	1
cgi.nph	0	0
cgi.redirect_status_env	no value	no value
cgi.rfc2616_headers	0	0
fastcgi.logging	1	1

Core
PHP Version 	5.4.32

Directive	Local Value	Master Value
allow_url_fopen	On	On
allow_url_include	On	On
always_populate_raw_post_data	Off	Off
arg_separator.input	&	&
arg_separator.output	&	&
asp_tags	Off	Off
auto_append_file	no value	no value
auto_globals_jit	On	On
auto_prepend_file	no value	no value
browscap	no value	no value
default_charset	no value	no value
default_mimetype	text/html	text/html
disable_classes	no value	no value
disable_functions	no value	no value
display_errors	Off	Off
display_startup_errors	Off	Off
doc_root	no value	no value
docref_ext	no value	no value
docref_root	no value	no value
enable_dl	Off	Off
enable_post_data_reading	On	On
error_append_string	no value	no value
error_log	error_log	error_log
error_prepend_string	no value	no value
error_reporting	22527	22527
exit_on_timeout	Off	Off
expose_php	Off	Off
extension_dir	/usr/php/54/usr/lib64/php/modules	/usr/php/54/usr/lib64/php/modules
file_uploads	On	On
highlight.comment	#FF8000	#FF8000
highlight.default	#0000BB	#0000BB
highlight.html	#000000	#000000
highlight.keyword	#007700	#007700
highlight.string	#DD0000	#DD0000
html_errors	On	On
ignore_repeated_errors	On	On
ignore_repeated_source	On	On
ignore_user_abort	Off	Off
implicit_flush	Off	Off
include_path	.:/usr/php/54/usr/lib64:/usr/php/54/usr/share/pear	.:/usr/php/54/usr/lib64:/usr/php/54/usr/share/pear
log_errors	On	On
log_errors_max_len	1024	1024
mail.add_x_header	On	On
mail.force_extra_parameters	no value	no value
mail.log	no value	no value
max_execution_time	30	30
max_file_uploads	20	20
max_input_nesting_level	64	64
max_input_time	60	60
max_input_vars	1000	1000
memory_limit	128M	128M
open_basedir	no value	no value
output_buffering	4096	4096
output_handler	no value	no value
post_max_size	50M	50M
precision	14	14
realpath_cache_size	16K	16K
realpath_cache_ttl	120	120
register_argc_argv	Off	Off
report_memleaks	On	On
report_zend_debug	On	On
request_order	GP	GP
sendmail_from	no value	no value
sendmail_path	/usr/sbin/sendmail -t -i	/usr/sbin/sendmail -t -i
serialize_precision	17	17
short_open_tag	On	On
SMTP	localhost	localhost
smtp_port	25	25
sql.safe_mode	Off	Off
track_errors	Off	Off
unserialize_callback_func	no value	no value
upload_max_filesize	50M	50M
upload_tmp_dir	no value	no value
user_dir	no value	no value
user_ini.cache_ttl	300	300
user_ini.filename	.user.ini	.user.ini
variables_order	GPCS	GPCS
xmlrpc_error_number	0	0
xmlrpc_errors	Off	Off
zend.detect_unicode	On	On
zend.enable_gc	On	On
zend.multibyte	Off	Off
zend.script_encoding	no value	no value

ctype
ctype functions 	enabled

curl
cURL support 	enabled
cURL Information 	7.24.0
Age 	3
Features
AsynchDNS 	Yes
Debug 	No
GSS-Negotiate 	Yes
IDN 	Yes
IPv6 	Yes
Largefile 	Yes
NTLM 	Yes
SPNEGO 	No
SSL 	Yes
SSPI 	No
krb4 	No
libz 	Yes
CharConv 	No
Protocols 	dict, file, ftp, ftps, gopher, http, https, imap, imaps, ldap, ldaps, pop3, pop3s, rtsp, scp, sftp, smtp, smtps, telnet, tftp
Host 	x86_64-unknown-linux-gnu
SSL Version 	OpenSSL/1.0.0
ZLib Version 	1.2.3
libSSH Version 	libssh2/1.2.2

date
date/time support 	enabled
"Olson" Timezone Database Version 	0.system
Timezone Database 	internal
Default timezone 	America/Denver

Directive	Local Value	Master Value
date.default_latitude	31.7667	31.7667
date.default_longitude	35.2333	35.2333
date.sunrise_zenith	90.583333	90.583333
date.sunset_zenith	90.583333	90.583333
date.timezone	America/Denver	America/Denver

dba
DBA support 	enabled
libdb header version 	Berkeley DB 4.7.25: (September 12, 2013)
libdb library version 	Berkeley DB 4.7.25: (September 12, 2013)
Supported handlers 	cdb cdb_make db4 inifile flatfile

Directive	Local Value	Master Value
dba.default_handler	flatfile	flatfile

dom
DOM/XML 	enabled
DOM/XML API Version 	20031129
libxml Version 	2.7.6
HTML Support 	enabled
XPath Support 	enabled
XPointer Support 	enabled
Schema Support 	enabled
RelaxNG Support 	enabled

enchant
enchant support	enabled
Version 	1.1.0
Revision 	$Id: 6de2feac8047059326b85565067ecdba8fb4f363 $

myspell 	Myspell Provider 	/usr/lib64/enchant/libenchant_myspell.so

ereg
Regex Library 	Bundled library enabled

exif
EXIF Support 	enabled
EXIF Version 	1.4 $Id: 38907b4d942a8d2419060a688aa3c5e5dedcb118 $
Supported EXIF Version 	0220
Supported filetypes 	JPEG,TIFF

Directive	Local Value	Master Value
exif.decode_jis_intel	JIS	JIS
exif.decode_jis_motorola	JIS	JIS
exif.decode_unicode_intel	UCS-2LE	UCS-2LE
exif.decode_unicode_motorola	UCS-2BE	UCS-2BE
exif.encode_jis	no value	no value
exif.encode_unicode	ISO-8859-15	ISO-8859-15

fileinfo
fileinfo support 	enabled
version 	1.0.5

filter
Input Validation and Filtering 	enabled
Revision 	$Id: ad78b4a085153b8c7f4d6db5dc69df40e969c343 $

Directive	Local Value	Master Value
filter.default	unsafe_raw	unsafe_raw
filter.default_flags	no value	no value

ftp
FTP support 	enabled

gd
GD Support 	enabled
GD Version 	bundled (2.1.0 compatible)
FreeType Support 	enabled
FreeType Linkage 	with freetype
FreeType Version 	2.3.11
T1Lib Support 	enabled
GIF Read Support 	enabled
GIF Create Support 	enabled
JPEG Support 	enabled
libJPEG Version 	6b
PNG Support 	enabled
libPNG Version 	1.2.49
WBMP Support 	enabled
XPM Support 	enabled
libXpm Version 	30411
XBM Support 	enabled

Directive	Local Value	Master Value
gd.jpeg_ignore_warning	0	0

gettext
GetText Support 	enabled

gmp
gmp support 	enabled
GMP version 	4.3.1

hash
hash support 	enabled
Hashing Engines 	md2 md4 md5 sha1 sha224 sha256 sha384 sha512 ripemd128 ripemd160 ripemd256 ripemd320 whirlpool tiger128,3 tiger160,3 tiger192,3 tiger128,4 tiger160,4 tiger192,4 snefru snefru256 gost adler32 crc32 crc32b fnv132 fnv164 joaat haval128,3 haval160,3 haval192,3 haval224,3 haval256,3 haval128,4 haval160,4 haval192,4 haval224,4 haval256,4 haval128,5 haval160,5 haval192,5 haval224,5 haval256,5

http
HTTP Support	enabled
Extension Version 	1.7.6
Registered Classes 	HttpUtil, HttpMessage, HttpRequest, HttpRequestPool, HttpRequestDataShare, HttpDeflateStream, HttpInflateStream, HttpResponse, HttpQueryString
Output Handlers 	ob_deflatehandler, ob_inflatehandler, ob_etaghandler
Stream Filters 	http.chunked_decode, http.chunked_encode, http.deflate, http.inflate

Used Library	Compiled	Linked
libcurl 	7.24.0 	7.24.0
libevent 	disabled 	disabled
libz 	1.2.3 	1.2.3
libmagic 	disabled 	disabled

Persistent Handles
Provider	Ident	Used	Free
http_request 	N/A 	0 	0
http_request_datashare 	GLOBAL 	1 	0
http_request_pool 	N/A 	0 	0

Request Methods
Registered 	GET, HEAD, POST, PUT, DELETE, OPTIONS, TRACE, CONNECT, PROPFIND, PROPPATCH, MKCOL, COPY, MOVE, LOCK, UNLOCK, VERSION-CONTROL, REPORT, CHECKOUT, CHECKIN, UNCHECKOUT, MKWORKSPACE, UPDATE, LABEL, MERGE, BASELINE-CONTROL, MKACTIVITY, ACL,
Allowed 	(ANY)

Directive	Local Value	Master Value
http.etag.mode	MD5	MD5
http.force_exit	1	1
http.log.allowed_methods	no value	no value
http.log.cache	no value	no value
http.log.composite	no value	no value
http.log.not_found	no value	no value
http.log.redirect	no value	no value
http.only_exceptions	0	0
http.persistent.handles.ident	GLOBAL	GLOBAL
http.persistent.handles.limit	-1	-1
http.request.datashare.connect	0	0
http.request.datashare.cookie	0	0
http.request.datashare.dns	1	1
http.request.datashare.ssl	0	0
http.request.methods.allowed	no value	no value
http.request.methods.custom	no value	no value
http.send.deflate.start_auto	0	0
http.send.deflate.start_flags	0	0
http.send.inflate.start_auto	0	0
http.send.inflate.start_flags	0	0
http.send.not_found_404	1	1

iconv
iconv support 	enabled
iconv implementation 	glibc
iconv library version 	2.12

Directive	Local Value	Master Value
iconv.input_encoding	ISO-8859-1	ISO-8859-1
iconv.internal_encoding	ISO-8859-1	ISO-8859-1
iconv.output_encoding	ISO-8859-1	ISO-8859-1

imagick
imagick module	enabled
imagick module version 	3.1.2
imagick classes 	Imagick, ImagickDraw, ImagickPixel, ImagickPixelIterator
ImageMagick version 	ImageMagick 6.7.9-10 2012-10-05 Q16 http://www.imagemagick.org
ImageMagick copyright 	Copyright (C) 1999-2012 ImageMagick Studio LLC
ImageMagick release date 	2012-10-05
ImageMagick number of supported formats: 	210
ImageMagick supported formats 	3FR, A, AAI, AI, ART, ARW, AVI, AVS, B, BGR, BGRA, BMP, BMP2, BMP3, BRF, C, CAL, CALS, CANVAS, CAPTION, CIN, CIP, CLIP, CMYK, CMYKA, CR2, CRW, CUR, CUT, DCM, DCR, DCX, DDS, DFONT, DJVU, DNG, DOT, DPX, EPDF, EPI, EPS, EPS2, EPS3, EPSF, EPSI, EPT, EPT2, EPT3, ERF, FAX, FITS, FRACTAL, FTS, G, G3, GIF, GIF87, GRADIENT, GRAY, GROUP4, HALD, HDR, HISTOGRAM, HRZ, HTM, HTML, ICB, ICO, ICON, INFO, INLINE, IPL, ISOBRL, J2C, J2K, JNG, JNX, JP2, JPC, JPEG, JPG, JPX, K, K25, KDC, LABEL, M, M2V, M4V, MAC, MAP, MAT, MATTE, MEF, MIFF, MNG, MONO, MOV, MP4, MPC, MPEG, MPG, MRW, MSL, MSVG, MTV, MVG, NEF, NRW, NULL, O, ORF, OTB, OTF, PAL, PALM, PAM, PANGO, PATTERN, PBM, PCD, PCDS, PCL, PCT, PCX, PDB, PDF, PDFA, PEF, PES, PFA, PFB, PFM, PGM, PGX, PICON, PICT, PIX, PJPEG, PLASMA, PNG, PNG24, PNG32, PNG8, PNM, PPM, PREVIEW, PS, PS2, PS3, PSB, PSD, PTIF, PWP, R, RADIAL-GRADIENT, RAF, RAS, RGB, RGBA, RGBO, RLA, RLE, SCR, SCT, SFW, SGI, SHTML, SR2, SRF, STEGANO, SUN, SVG, SVGZ, TEXT, TGA, THUMBNAIL, TIFF, TIFF64, TILE, TIM, TTC, TTF, TXT, UBRL, UIL, UYVY, VDA, VICAR, VID, VIFF, VST, WBMP, WMF, WMV, WMZ, WPG, X, X3F, XBM, XC, XCF, XPM, XPS, XV, XWD, Y, YCbCr, YCbCrA, YUV

Directive	Local Value	Master Value
imagick.locale_fix	0	0
imagick.progress_monitor	0	0

imap
IMAP c-Client Version 	2007e
SSL Support 	enabled
Kerberos Support 	enabled

intl
Internationalization support	enabled
version 	1.1.0
ICU version 	4.2.1

Directive	Local Value	Master Value
intl.default_locale	no value	no value
intl.error_level	0	0

json
json support 	enabled
json version 	1.2.1

ldap
LDAP Support 	enabled
RCS Version 	$Id: 9fe48a03aa04ed57ef752b0aad632b912205545f $
Total Links 	0/unlimited
API Version 	3001
Vendor Name 	OpenLDAP
Vendor Version 	20423
SASL Support 	Enabled

Directive	Local Value	Master Value
ldap.max_links	Unlimited	Unlimited

libxml
libXML support 	active
libXML Compiled Version 	2.7.6
libXML Loaded Version 	20706
libXML streams 	enabled

mbstring
Multibyte Support 	enabled
Multibyte string engine 	libmbfl
HTTP input encoding translation 	disabled
libmbfl version 	1.3.2

mbstring extension makes use of "streamable kanji code filter and converter", which is distributed under the GNU Lesser General Public License version 2.1.

Multibyte (japanese) regex support 	enabled
Multibyte regex (oniguruma) backtrack check 	On
Multibyte regex (oniguruma) version 	4.7.1

Directive	Local Value	Master Value
mbstring.detect_order	no value	no value
mbstring.encoding_translation	Off	Off
mbstring.func_overload	0	0
mbstring.http_input	pass	pass
mbstring.http_output	pass	pass
mbstring.http_output_conv_mimetypes	^(text/|application/xhtml\+xml)	^(text/|application/xhtml\+xml)
mbstring.internal_encoding	no value	no value
mbstring.language	neutral	neutral
mbstring.strict_detection	Off	Off
mbstring.substitute_character	no value	no value

mcrypt
mcrypt support	enabled
mcrypt_filter support	enabled
Version 	2.5.8
Api No 	20021217
Supported ciphers 	cast-128 gost rijndael-128 twofish arcfour cast-256 loki97 rijndael-192 saferplus wake blowfish-compat des rijndael-256 serpent xtea blowfish enigma rc2 tripledes
Supported modes 	cbc cfb ctr ecb ncfb nofb ofb stream

Directive	Local Value	Master Value
mcrypt.algorithms_dir	no value	no value
mcrypt.modes_dir	no value	no value

mhash
MHASH support 	Enabled
MHASH API Version 	Emulated Support

mysql
MySQL Support	enabled
Active Persistent Links 	0
Active Links 	0
Client API version 	5.5.37
MYSQL_MODULE_TYPE 	external
MYSQL_SOCKET 	/var/lib/mysql/mysql.sock
MYSQL_INCLUDE 	-I/usr/include/mysql
MYSQL_LIBS 	-L/usr/lib64/mysql -lmysqlclient

Directive	Local Value	Master Value
mysql.allow_local_infile	On	On
mysql.allow_persistent	On	On
mysql.connect_timeout	60	60
mysql.default_host	no value	no value
mysql.default_password	no value	no value
mysql.default_port	no value	no value
mysql.default_socket	/var/lib/mysql/mysql.sock	/var/lib/mysql/mysql.sock
mysql.default_user	no value	no value
mysql.max_links	Unlimited	Unlimited
mysql.max_persistent	Unlimited	Unlimited
mysql.trace_mode	Off	Off

mysqli
MysqlI Support	enabled
Client API library version 	5.5.37
Active Persistent Links 	0
Inactive Persistent Links 	0
Active Links 	0
Client API header version 	5.5.37
MYSQLI_SOCKET 	/var/lib/mysql/mysql.sock

Directive	Local Value	Master Value
mysqli.allow_local_infile	On	On
mysqli.allow_persistent	On	On
mysqli.default_host	no value	no value
mysqli.default_port	3306	3306
mysqli.default_pw	no value	no value
mysqli.default_socket	/var/lib/mysql/mysql.sock	/var/lib/mysql/mysql.sock
mysqli.default_user	no value	no value
mysqli.max_links	Unlimited	Unlimited
mysqli.max_persistent	Unlimited	Unlimited
mysqli.reconnect	Off	Off

OAuth
OAuth support	enabled
PLAINTEXT support 	enabled
RSA-SHA1 support 	enabled
HMAC-SHA1 support 	enabled
Request engine support 	php_streams
source version 	$Id: oauth.c 325799 2012-05-24 21:07:51Z jawed $
version 	1.2.3

odbc
ODBC Support	enabled
Active Persistent Links 	0
Active Links 	0
ODBC library 	unixODBC
ODBC_INCLUDE 	-I/usr/include
ODBC_LFLAGS 	-L/usr/lib64
ODBC_LIBS 	-lodbc

Directive	Local Value	Master Value
odbc.allow_persistent	On	On
odbc.check_persistent	On	On
odbc.default_cursortype	Static cursor	Static cursor
odbc.default_db	no value	no value
odbc.default_pw	no value	no value
odbc.default_user	no value	no value
odbc.defaultbinmode	return as is	return as is
odbc.defaultlrl	return up to 4096 bytes	return up to 4096 bytes
odbc.max_links	Unlimited	Unlimited
odbc.max_persistent	Unlimited	Unlimited

openssl
OpenSSL support 	enabled
OpenSSL Library Version 	OpenSSL 1.0.1e-fips 11 Feb 2013
OpenSSL Header Version 	OpenSSL 1.0.1e-fips 11 Feb 2013

pcntl
pcntl support	enabled

pcre
PCRE (Perl Compatible Regular Expressions) Support 	enabled
PCRE Library Version 	8.32 2012-11-30

Directive	Local Value	Master Value
pcre.backtrack_limit	1000000	1000000
pcre.recursion_limit	100000	100000

PDO
PDO support	enabled
PDO drivers 	dblib, mysql, odbc, pgsql, sqlite

pdo_dblib
PDO Driver for FreeTDS/Sybase DB-lib	enabled
Flavour 	freetds

pdo_mysql
PDO Driver for MySQL	enabled
Client API version 	5.5.37

Directive	Local Value	Master Value
pdo_mysql.default_socket	/var/lib/mysql/mysql.sock	/var/lib/mysql/mysql.sock

PDO_ODBC
PDO Driver for ODBC (unixODBC)	enabled
ODBC Connection Pooling 	Enabled, strict matching

pdo_pgsql
PDO Driver for PostgreSQL	enabled
PostgreSQL(libpq) Version 	8.4.20
Module version 	1.0.2
Revision 	$Id: 8e4cc97fb53f418d98b489c3e9d722e48446e676 $

pdo_sqlite
PDO Driver for SQLite 3.x	enabled
SQLite Library 	3.7.7.1

pgsql
PostgreSQL Support	enabled
PostgreSQL(libpq) Version 	8.4.20
PostgreSQL(libpq) 	PostgreSQL 8.4.20 on x86_64-redhat-linux-gnu, compiled by GCC gcc (GCC) 4.4.7 20120313 (Red Hat 4.4.7-4), 64-bit
Multibyte character support 	enabled
SSL support 	enabled
Active Persistent Links 	0
Active Links 	0

Directive	Local Value	Master Value
pgsql.allow_persistent	On	On
pgsql.auto_reset_persistent	Off	Off
pgsql.ignore_notice	Off	Off
pgsql.log_notice	Off	Off
pgsql.max_links	Unlimited	Unlimited
pgsql.max_persistent	Unlimited	Unlimited

Phar
Phar: PHP Archive support	enabled
Phar EXT version 	2.0.1
Phar API version 	1.1.1
SVN revision 	$Id: ec823514107160b7e6fabc519594012657a2db91 $
Phar-based phar archives 	enabled
Tar-based phar archives 	enabled
ZIP-based phar archives 	enabled
gzip compression 	enabled
bzip2 compression 	enabled
Native OpenSSL support 	enabled

Phar based on pear/PHP_Archive, original concept by Davey Shafik.
Phar fully realized by Gregory Beaver and Marcus Boerger.
Portions of tar implementation Copyright (c) 2003-2009 Tim Kientzle.

Directive	Local Value	Master Value
phar.cache_list	no value	no value
phar.readonly	On	On
phar.require_hash	On	On

posix
Revision 	$Id: 1dfa9997ed76804e53c91e0ce862f3707617b6ed $

pspell
PSpell Support 	enabled

readline
Readline Support	enabled
Readline library 	EditLine wrapper

Directive	Local Value	Master Value
cli.pager	no value	no value
cli.prompt	\b \> 	\b \> 

recode
Recode Support 	enabled
Revision 	$Id: 3fff0a7f7f38d14822c458730319d132d602a061 $

Reflection
Reflection	enabled
Version 	$Id: f6367cdb4e3f392af4a6d441a6641de87c2e50c4 $

session
Session Support 	enabled
Registered save handlers 	files user
Registered serializer handlers 	php php_binary wddx

Directive	Local Value	Master Value
session.auto_start	Off	Off
session.cache_expire	180	180
session.cache_limiter	nocache	nocache
session.cookie_domain	no value	no value
session.cookie_httponly	Off	Off
session.cookie_lifetime	0	0
session.cookie_path	/	/
session.cookie_secure	Off	Off
session.entropy_file	/dev/urandom	/dev/urandom
session.entropy_length	0	0
session.gc_divisor	1000	1000
session.gc_maxlifetime	1440	1440
session.gc_probability	1	1
session.hash_bits_per_character	5	5
session.hash_function	0	0
session.name	PHPSESSID	PHPSESSID
session.referer_check	no value	no value
session.save_handler	files	files
session.save_path	/tmp	/tmp
session.serialize_handler	php	php
session.upload_progress.cleanup	On	On
session.upload_progress.enabled	On	On
session.upload_progress.freq	1%	1%
session.upload_progress.min_freq	1	1
session.upload_progress.name	PHP_SESSION_UPLOAD_PROGRESS	PHP_SESSION_UPLOAD_PROGRESS
session.upload_progress.prefix	upload_progress_	upload_progress_
session.use_cookies	On	On
session.use_only_cookies	On	On
session.use_trans_sid	0	0

shmop
shmop support 	enabled

SimpleXML
Simplexml support	enabled
Revision 	$Id: 16070fc92ad6f69cebb2d52ad3f02794f833ce39 $
Schema support 	enabled

soap
Soap Client 	enabled
Soap Server 	enabled

Directive	Local Value	Master Value
soap.wsdl_cache	1	1
soap.wsdl_cache_dir	/tmp	/tmp
soap.wsdl_cache_enabled	1	1
soap.wsdl_cache_limit	5	5
soap.wsdl_cache_ttl	86400	86400

sockets
Sockets Support 	enabled

SPL
SPL support	enabled
Interfaces 	Countable, OuterIterator, RecursiveIterator, SeekableIterator, SplObserver, SplSubject
Classes 	AppendIterator, ArrayIterator, ArrayObject, BadFunctionCallException, BadMethodCallException, CachingIterator, CallbackFilterIterator, DirectoryIterator, DomainException, EmptyIterator, FilesystemIterator, FilterIterator, GlobIterator, InfiniteIterator, InvalidArgumentException, IteratorIterator, LengthException, LimitIterator, LogicException, MultipleIterator, NoRewindIterator, OutOfBoundsException, OutOfRangeException, OverflowException, ParentIterator, RangeException, RecursiveArrayIterator, RecursiveCachingIterator, RecursiveCallbackFilterIterator, RecursiveDirectoryIterator, RecursiveFilterIterator, RecursiveIteratorIterator, RecursiveRegexIterator, RecursiveTreeIterator, RegexIterator, RuntimeException, SplDoublyLinkedList, SplFileInfo, SplFileObject, SplFixedArray, SplHeap, SplMinHeap, SplMaxHeap, SplObjectStorage, SplPriorityQueue, SplQueue, SplStack, SplTempFileObject, UnderflowException, UnexpectedValueException

sqlite3
SQLite3 support	enabled
SQLite3 module version 	0.7
SQLite Library 	3.7.7.1

Directive	Local Value	Master Value
sqlite3.extension_dir	no value	no value

standard
Dynamic Library Support 	enabled
Path to sendmail 	/usr/sbin/sendmail -t -i

Directive	Local Value	Master Value
assert.active	1	1
assert.bail	0	0
assert.callback	no value	no value
assert.quiet_eval	0	0
assert.warning	1	1
auto_detect_line_endings	0	0
default_socket_timeout	60	60
from	no value	no value
url_rewriter.tags	a=href,area=href,frame=src,input=src,form=fakeentry	a=href,area=href,frame=src,input=src,form=fakeentry
user_agent	no value	no value

sysvmsg
sysvmsg support 	enabled
Revision 	$Id: adf1d2d6be849c46eed3c3ee6f1cbebd1448d6e5 $

tidy
Tidy support	enabled
libTidy Release 	14 June 2007
Extension Version 	2.0 ($Id: 14aff36094bdd63f1d0adee006215e5e553294ea $)

Directive	Local Value	Master Value
tidy.clean_output	no value	no value
tidy.default_config	no value	no value

tokenizer
Tokenizer Support 	enabled

wddx
WDDX Support	enabled
WDDX Session Serializer 	enabled

xml
XML Support 	active
XML Namespace Support 	active
libxml2 Version 	2.7.6

xmlreader
XMLReader 	enabled

xmlrpc
core library version 	xmlrpc-epi v. 0.51
php extension version 	0.51
author 	Dan Libby
homepage 	http://xmlrpc-epi.sourceforge.net
open sourced by 	Epinions.com

xmlwriter
XMLWriter 	enabled

xsl
XSL 	enabled
libxslt Version 	1.1.26
libxslt compiled against libxml Version 	2.7.6
EXSLT 	enabled
libexslt Version 	1.1.26

Zend Guard Loader
Zend Guard Loader 	enabled
License Path 	no value
Obfuscation level 	0

zip
Zip 	enabled
Extension Version 	$Id: abc21c7f1559e732dba6db94c69ecf638ae5fa3f $
Zip version 	1.11.0
Libzip version 	0.10.1

zlib
ZLib Support	enabled
Stream Wrapper 	compress.zlib://
Stream Filter 	zlib.inflate, zlib.deflate
Compiled Version 	1.2.3
Linked Version 	1.2.3

Directive	Local Value	Master Value
zlib.output_compression	Off	Off
zlib.output_compression_level	-1	-1
zlib.output_handler	no value	no value

Additional Modules
Module Name
sysvsem
sysvshm

Environment
Variable	Value
DOCUMENT_ROOT 	/home2/thecoins/public_html
GATEWAY_INTERFACE 	CGI/1.1
HTTP_ACCEPT 	text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
HTTP_ACCEPT_ENCODING 	gzip, deflate
HTTP_ACCEPT_LANGUAGE 	en-US,en;q=0.5
HTTP_CONNECTION 	keep-alive
HTTP_COOKIE 	sc_wp_session=64d6cf6f4cad43435ff4f2da62349532%7C%7C2826510756%7C%7C1413235218; wp-settings-time-1000=1413154946; wordpress_logged_in_780f442883ce7e2e30fc4017f57e3b7c=developer%7C1414098823%7Cie2iFkIyu35KdpaVCb45qmLpGiPl9wP5Wuv2RbZtnnl%7C01da1ad7d37554f5ab71110c63e1430a365a90dab521f05684d920171f34989b; wp-settings-1000=editor%3Dtinymce
HTTP_DNT 	1
HTTP_HOST 	thecoinsultants.com
HTTP_USER_AGENT 	Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:32.0) Gecko/20100101 Firefox/32.0
MAGICK_THREAD_LIMIT 	1
PATH 	/bin:/usr/bin
QUERY_STRING 	no value
REDIRECT_STATUS 	200
REMOTE_ADDR 	107.211.136.240
REMOTE_PORT 	55034
REQUEST_METHOD 	GET
REQUEST_URI 	/info.php
SCRIPT_FILENAME 	/home2/thecoins/public_html/info.php
SCRIPT_NAME 	/info.php
SERVER_ADDR 	69.195.110.74
SERVER_ADMIN 	webmaster@thecoinsultants.com
SERVER_NAME 	thecoinsultants.com
SERVER_PORT 	80
SERVER_PROTOCOL 	HTTP/1.1
SERVER_SIGNATURE 	<address>Apache Server at thecoinsultants.com Port 80</address>
SERVER_SOFTWARE 	Apache
UNIQUE_ID 	VDxrbUXDfLsAAAHwgRQAAAQQ

PHP Variables
Variable	Value
_COOKIE["sc_wp_session"]	64d6cf6f4cad43435ff4f2da62349532||2826510756||1413235218
_COOKIE["wp-settings-time-1000"]	1413154946
_COOKIE["wordpress_logged_in_780f442883ce7e2e30fc4017f57e3b7c"]	developer|1414098823|ie2iFkIyu35KdpaVCb45qmLpGiPl9wP5Wuv2RbZtnnl|01da1ad7d37554f5ab71110c63e1430a365a90dab521f05684d920171f34989b
_COOKIE["wp-settings-1000"]	editor=tinymce
_SERVER["DOCUMENT_ROOT"]	/home2/thecoins/public_html
_SERVER["GATEWAY_INTERFACE"]	CGI/1.1
_SERVER["HTTP_ACCEPT"]	text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
_SERVER["HTTP_ACCEPT_ENCODING"]	gzip, deflate
_SERVER["HTTP_ACCEPT_LANGUAGE"]	en-US,en;q=0.5
_SERVER["HTTP_CONNECTION"]	keep-alive
_SERVER["HTTP_COOKIE"]	sc_wp_session=64d6cf6f4cad43435ff4f2da62349532%7C%7C2826510756%7C%7C1413235218; wp-settings-time-1000=1413154946; wordpress_logged_in_780f442883ce7e2e30fc4017f57e3b7c=developer%7C1414098823%7Cie2iFkIyu35KdpaVCb45qmLpGiPl9wP5Wuv2RbZtnnl%7C01da1ad7d37554f5ab71110c63e1430a365a90dab521f05684d920171f34989b; wp-settings-1000=editor%3Dtinymce
_SERVER["HTTP_DNT"]	1
_SERVER["HTTP_HOST"]	thecoinsultants.com
_SERVER["HTTP_USER_AGENT"]	Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:32.0) Gecko/20100101 Firefox/32.0
_SERVER["MAGICK_THREAD_LIMIT"]	1
_SERVER["PATH"]	/bin:/usr/bin
_SERVER["QUERY_STRING"]	no value
_SERVER["REDIRECT_STATUS"]	200
_SERVER["REMOTE_ADDR"]	107.211.136.240
_SERVER["REMOTE_PORT"]	55034
_SERVER["REQUEST_METHOD"]	GET
_SERVER["REQUEST_URI"]	/info.php
_SERVER["SCRIPT_FILENAME"]	/home2/thecoins/public_html/info.php
_SERVER["SCRIPT_NAME"]	/info.php
_SERVER["SERVER_ADDR"]	69.195.110.74
_SERVER["SERVER_ADMIN"]	webmaster@thecoinsultants.com
_SERVER["SERVER_NAME"]	thecoinsultants.com
_SERVER["SERVER_PORT"]	80
_SERVER["SERVER_PROTOCOL"]	HTTP/1.1
_SERVER["SERVER_SIGNATURE"]	<address>Apache Server at thecoinsultants.com Port 80</address>
_SERVER["SERVER_SOFTWARE"]	Apache
_SERVER["UNIQUE_ID"]	VDxrbUXDfLsAAAHwgRQAAAQQ
_SERVER["PHP_SELF"]	/info.php
_SERVER["REQUEST_TIME_FLOAT"]	1413245805.3734
_SERVER["REQUEST_TIME"]	1413245805

PHP License

This program is free software; you can redistribute it and/or modify it under the terms of the PHP License as published by the PHP Group and included in the distribution in the file: LICENSE

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

If you did not receive a copy of the PHP license, or have any questions about PHP licensing, please contact license@php.net.


